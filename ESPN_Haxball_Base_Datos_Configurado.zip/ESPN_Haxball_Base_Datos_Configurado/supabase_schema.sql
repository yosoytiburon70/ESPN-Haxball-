-- ESPN Haxball: base de datos compartida
-- Ejecuta todo este archivo en Supabase > SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.jugadores (
  id uuid primary key,
  nombre text not null,
  goles integer not null default 0 check (goles >= 0),
  asistencias integer not null default 0 check (asistencias >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.configuracion (
  clave text primary key,
  valor text not null
);

insert into public.configuracion (clave, valor)
values ('temporada', 'ESPN HAXBALL')
on conflict (clave) do nothing;

alter table public.jugadores enable row level security;
alter table public.configuracion enable row level security;

-- Cualquiera puede ver la tabla.
drop policy if exists "public_read_jugadores" on public.jugadores;
create policy "public_read_jugadores"
on public.jugadores
for select
to anon, authenticated
using (true);

drop policy if exists "admin_insert_jugadores" on public.jugadores;
create policy "admin_insert_jugadores"
on public.jugadores
for insert
to authenticated
with check (true);

drop policy if exists "admin_update_jugadores" on public.jugadores;
create policy "admin_update_jugadores"
on public.jugadores
for update
to authenticated
using (true)
with check (true);

drop policy if exists "admin_delete_jugadores" on public.jugadores;
create policy "admin_delete_jugadores"
on public.jugadores
for delete
to authenticated
using (true);

drop policy if exists "public_read_configuracion" on public.configuracion;
create policy "public_read_configuracion"
on public.configuracion
for select
to anon, authenticated
using (true);

drop policy if exists "admin_insert_configuracion" on public.configuracion;
create policy "admin_insert_configuracion"
on public.configuracion
for insert
to authenticated
with check (true);

drop policy if exists "admin_update_configuracion" on public.configuracion;
create policy "admin_update_configuracion"
on public.configuracion
for update
to authenticated
using (true)
with check (true);

-- Permisos mínimos para la aplicación.
grant select on public.jugadores to anon, authenticated;
grant insert, update, delete on public.jugadores to authenticated;
grant select on public.configuracion to anon, authenticated;
grant insert, update on public.configuracion to authenticated;

-- Habilita actualizaciones en tiempo real para que las tablas abiertas
-- en otros dispositivos reciban los cambios.
alter publication supabase_realtime add table public.jugadores;
alter publication supabase_realtime add table public.configuracion;
